#include <REGX51.H>
void init_ckt(void);
void InitSerial(void);
void send_msg(unsigned char *c);
void send_tx(unsigned char);
sbit led1 = P1^0;
sbit led2 = P1^1;
sbit led3 = P1^2;
sbit led4 = P1^3;
void main()
{
	init_ckt();
	InitSerial();
	EA = 1;
	ES = 1;
	send_msg("THE SERIAL COMMUNICATION PORT IS INITIALIZED.");
	send_tx(0x0d);
	send_msg("To turn on LEDs press key 9,8,7,6 and to turn off them press p,q,r,s respectively.");
	send_tx(0x0d); //next line
	send_msg("PRESS ANY OF THE SAID KEYS...");
	send_tx(0x0d);
	while(1){}
}
void init_ckt(void) //initialize cct
{
	P0 = 0x00; //not used
	P1 = 0x00; //output port used for leds
	P2 = 0x00; //not used
	P3 = 0x03; //used for serial communication
}

void InitSerial(void) //Initialize Serial Port
{
	TMOD = 0x20; //Timer 1 In Mode 2 -Auto Reload to Generate Baud Rate
	SCON = 0x50; //Serial Mode 1, 8-Data Bit, REN Enabled
	TH1 = 0xFD; //Load Baud Rate 9600 To Timer Register
	TR1 = 1; //Start Timer
}

void send_msg(unsigned char *c)
{
	while(*c != 0)
	{
		send_tx(*c++);
		//led2 = ~led2;
	}
}

void send_tx(unsigned char sdata)
{
	SBUF = sdata; //Load Data to Serial Buffer Register
	while(TI == 0); //Wait Until Transmission To Complete
	TI = 0; //Clear Transmission Interrupt Flag
}
void receive_ISR (void) interrupt 4
{
	char ch; //receive character
	if(RI==1)
	{
		ch = SBUF;
		RI = 0;	   //Clear Receive Interrupt flag
	}
	//P0 = ~P0; //Show the data has been updated
	switch(ch)
	{
		case '9': led1 = 1; send_msg("1st on"); send_tx(0x0d); break;
		case '8': led2 = 1; send_msg("2nd on"); send_tx(0x0d); break;

		case '7': led3 = 1; send_msg("3rd on"); send_tx(0x0d); break;
		case '6': led4 = 1; send_msg("4th on"); send_tx(0x0d); break;
		case 'p': led1 = 0; send_msg("1st off"); send_tx(0x0d); break;
		case 'q': led2 = 0; send_msg("2nd off"); send_tx(0x0d); break;
		case 'r': led3 = 0; send_msg("3rd off"); send_tx(0x0d); break;
		case 's': led4 = 0; send_msg("4th off"); send_tx(0x0d); break;
		default:  break; //do nothing
	}
	RI = 0;
}